package HollomonPackage;


public class Card  implements Comparable<Card> {
	private long id;
	private String name;
	private Rank rank;
	private long price;
	
	public void setPrice(long price2) {
	//setter method to allow the price to be overwritten 
		this.price = price2;
	}
	
	public Card(long id, String name, Rank rank) {
		this.id = id;
		this.name = name;
		this.rank = rank;
		this.price = 0;
	}
	
	public long getID() { 
		return this.id;
	}
	
	public long getPrice() {
		return this.price;
	}
	
	public String toString() {
	//sample card: ID: 123, Name: pikachu, rank = UNIQUE, price = 100
		String s1 = "";
		s1 = ("ID: " + this.id + ", Name: " + this.name + ", rank = " + this.rank + ", price = " + this.price);
		return s1;
	}
	
	  public boolean equals(Object o) {
		  if (!(o instanceof Card)) {
			  return false; 
			  }
	  Card other = (Card) o; 
	  return (this.id == other.id &&  this.name.equals(other.name) && this.rank == other.rank); }
	 
	
	
	public int hashCode() {
	//bit shifting the id field 32 bits to the right
		return (int) ((id >> 32) ^ id);
	}
	
	
	@Override
	public int compareTo(Card o) {
	//sorts through the rarity then the name
		int result = this.rank.compareTo(o.rank);
		if (result == 0) {
			return this.name.compareTo(o.name);
		} else {
			return result;
		}
	}
	
	
}
