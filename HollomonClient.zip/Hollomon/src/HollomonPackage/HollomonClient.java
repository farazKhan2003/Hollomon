package HollomonPackage;


import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class HollomonClient {
private String server;
private InputStream is;
private OutputStream os;
BufferedWriter writer;
private int port;
private CardInputStream cis;
private List<Card> array =  new ArrayList<Card>();
private Socket socket;
	public HollomonClient(String serverarg, int portarg) throws UnknownHostException, IOException {
		this.server = serverarg;
		this.port = portarg;
		Socket socket = new Socket(this.server, this.port);
		this.socket = socket;
		 this.is = socket.getInputStream();
		 this.os = socket.getOutputStream();
		 cis = new CardInputStream(is);
		 //creating one input stream to use
	}
	

	
	public List<Card> login(String username, String password) throws IOException {
		writer = new BufferedWriter(new OutputStreamWriter(this.os));

		String correct = new String( "User " + username + " logged in successfully.");
		try {
			//this will check if the user has logged in successfully
		writer.write(username.toLowerCase() + "\n");
		writer.write(password + "\n");
		//this will verify logging in by sending the username (as lower case) and the password
		writer.flush();
		String temp = new String();
		Card tempcard;
		while ((temp = cis.readResponse())!=null) {
			//this reads the servers response
			if (temp.contentEquals(correct)) {
				//if the connection is successful the server sends card information which will be read below
				while ((tempcard = cis.readCard()) != null) {
				//reads a card then adds it to the array and continues until no more cards can be read
					array.add(tempcard);
					continue;
				}
				Collections.sort(array);
					//sorts the array by rank and name based on the Card class's compareTo() method
				return array;
				
			
			} else {
				continue;
			}
			
		}
		return null;
		} catch (UnknownHostException e) {
		//this is activated when connection has failed
			System.err.println("DIDNT CONNECT TO SERVER");
			return null;
		  }	
		}
	
	public long getCredits() throws IOException {
		//getCredits returns the current balance of the user.
		String temp;
		long val;
	
		writer = new BufferedWriter(new OutputStreamWriter(this.os));
		writer.write("CREDITS\n");
		writer.flush();
		
		if ((temp = cis.readResponse()) != "OK") {
		val = Long.parseLong(temp);
		return val;
		}
		return 0;
	}
	
	public List<Card> getCards() throws IOException {
	//getCards() retrieves an array of the users current owned set of cards
		List<Card> cardArray = new ArrayList<Card>();
		writer = new BufferedWriter(new OutputStreamWriter(this.os));
		writer.write("CARDS\n");
		writer.flush();
		Card card;
		while ((card = cis.readCard()) != null) {
			//this reads and adds the cards to the array
			cardArray.add(card);
			continue;
		}
		//the array is then sorted by rank then Name using the compareTo() in Card
		Collections.sort(cardArray);
		return cardArray;
		
	}
	
	public List<Card> getOffers() throws IOException {
	//getOffers() retrieves the current cards on offer to purchase
		List<Card> offercards = new ArrayList<Card>();
		writer = new BufferedWriter(new OutputStreamWriter(this.os));
		writer.write("OFFERS\n");
		writer.flush();

		Card card;
		while ((card = cis.readCard()) != null) {
			offercards.add(card);
			continue;
		}
		
		Collections.sort(offercards);
		return offercards;
		
	}
	
	public boolean buyCard(Card cardarg) throws IOException {
	//buyCard() allows the user to purchase a card by checking if their balance is greated than the cards price
		writer = new BufferedWriter(new OutputStreamWriter(this.os));
		String temp;
		String OK = new String("OK");
	
		writer.write("BUY " + cardarg.getID()+ "\n");
		writer.flush();
		while ((temp = cis.readResponse()) !=null) {
			if (temp.contentEquals(OK)) {
				return true;
			}
			return false;
		}
	return false;
	}

	public boolean sellCard(Card card, long price) throws IOException {
	//sellCard() allows the user to sell a card they no longer need
		writer = new BufferedWriter(new OutputStreamWriter(this.os));
		String temp;
		String OK = new String("OK");
		
		writer.write("SELL " + card.getID() + "\n") ;
		writer.flush();
		while ((temp = cis.readResponse()) != null) {
			if (temp.contentEquals(OK)) {
				return true;
			}
			return false;
		}
		return false;
	}
	
		public void close() throws IOException {
		//closing all streams and the course in order to prevent resource leaking
			this.is.close();
			this.os.close();
			this.socket.close();
	}
	
	  
	 }
