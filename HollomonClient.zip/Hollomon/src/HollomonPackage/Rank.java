package HollomonPackage;

public enum Rank {
//defining 4 rarities
	UNIQUE, RARE, UNCOMMON, COMMON;
}
