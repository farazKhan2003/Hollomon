package HollomonPackage;


import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
public class CardInputStream extends InputStream{
protected InputStreamReader is;
private int index;
private BufferedReader reader;
//using one BufferedReader for all reading allows the same inputStream to be reused as you can filter through the buffer several times
	public CardInputStream(InputStream input) throws IOException {
		 this.is = new InputStreamReader(input);
		this.reader = new BufferedReader(is);
	}

	@Override
	public int read() throws IOException {
		//this method was made purely to allow inheritance due to inheritance laws
		return 0;
	}
	
	
	@Override
	public void close() throws IOException {
	//the input stream is closed to stop resource leaking
		this.is.close();
	}
	
	public Card readCard() throws IOException {
		String temp;
		String name = null;
		long id = 0;
		Rank rank = null;
		long price = 0;
		int counter = 0;
		while ((temp = readResponse()) != null) {
			if (((String) temp).contentEquals("CARD")) {
			//read the CARD then start reading the card info
				temp = readResponse();
				while (counter < 5) {
					id = Long.valueOf(temp);
					counter++;
					temp = reader.readLine();
					counter++;
					name = temp;
					temp = reader.readLine();
					counter++;
					rank = Rank.valueOf(temp);
					counter++;
					temp = reader.readLine();
					price = Long.valueOf(temp);
					counter++;
				}
				Card card = new Card(id, name, rank);
				//setting the price so that it stays constant throughout all methods called upon that card
				card.setPrice(price);
				return card;
			}
			return null;
		}
		return null;
		
	}
	
	
	
public String readResponse() throws IOException {
	//this simply reads one line from the system
	String temp;
	while ((temp = reader.readLine())!=null) {
		return temp;
	}
	
	return null;

}
}
