package HollomonPackage;


import java.util.HashSet;

import java.util.Set;
import java.util.TreeSet;

public class CardTest {

	public CardTest() {
		
	}

	public static void main(String[] args) {
		Card cardUnique = new Card(1, "pikachu", Rank.UNIQUE);
		Card cardcommon = new Card(2, "charmander", Rank.COMMON);
		Card cardcommoncheck = new Card(2, "charmander", Rank.COMMON);
		Card carduncommon = new Card(3, "squirtle", Rank.UNCOMMON);
		Card cardRare = new Card(4, "abra", Rank.RARE);
		System.out.println(cardUnique.compareTo(carduncommon));
		System.out.println(cardcommon.equals(cardRare));
		System.out.println(cardcommon.equals(cardcommoncheck));
		Set <Card> hashset = new HashSet<Card>();
		hashset.add(cardRare);
		hashset.add(cardUnique);
		hashset.add(cardcommon);
		hashset.add(carduncommon);
		hashset.add(cardRare);
		Set<Card> treeset = new TreeSet<>();
		treeset.add(cardRare);
		treeset.add(cardUnique);
		treeset.add(cardcommon);
		treeset.add(carduncommon);
		treeset.add(cardRare);
		treeset.forEach(System.out::println);
	}

}
